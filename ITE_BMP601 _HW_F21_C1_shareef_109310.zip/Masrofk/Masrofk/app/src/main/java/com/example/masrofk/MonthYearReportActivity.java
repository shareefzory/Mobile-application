package com.example.masrofk;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class MonthYearReportActivity extends AppCompatActivity {
    Spinner spinner_year,spinner_month;
    Button bt_get_report;
    String[] year = new String[] {"No Select","2010","2011","2012","2013","2014","2015","2016","2017","2018","2019","2020","2021","2022"};
    String[] month = new String[] {"No Select","1","2","3","4","5","6","7","8","9","10","11","12"};
    String yearSelect;
    String monthSelect;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_month_year_report);
        spinner_year = (Spinner) findViewById(R.id.spinner_year);
        spinner_month = (Spinner) findViewById(R.id.spinner_month);
        bt_get_report = findViewById(R.id.bt_get_report);
        loadSpinnerDataYear();
        loadSpinnerDataMonth();
        db= openOrCreateDatabase("MasrofkDB", Context.MODE_PRIVATE,null);
        spinner_year.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long arg3) {
                spinner_year.setSelection(position);
//                id_material_help = id_material[position];
                yearSelect = year[position];
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });

        spinner_month.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long arg3) {
//                Arrays.asList(id_OutlayOwner).get(position);
                spinner_month.setSelection(position);
                monthSelect = month[position];
//                id_OutlayOwner_help = id_OutlayOwner[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
    }
    private void loadSpinnerDataMonth() {
        // Spinner Drop down elements
        List<String> lables = Arrays.asList(month);

        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, lables);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        spinner_month.setAdapter(dataAdapter);
    }

    private void loadSpinnerDataYear() {
        // Spinner Drop down elements
        List<String> lables = Arrays.asList(year);

        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, lables);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        spinner_year.setAdapter(dataAdapter);
    }

    public void onClick(View v){
        Cursor cursor =db.rawQuery("SELECT date,sum(price) as Total FROM Outlay WHERE SUBSTR(date, 1, 4) ='" + yearSelect + "' OR SUBSTR(date, 1,6) ='" + yearSelect +'/'+monthSelect+"' OR SUBSTR(date, 6,1) ='"+monthSelect+"' OR SUBSTR(date, 6,2) ='"+monthSelect+"' GROUP BY date ",null);
        if(v== bt_get_report) {
            if (cursor.getCount()==0) {
                showMessage("Error","No Record Found");
                return;
            } else  {
                StringBuffer buffer = new StringBuffer();
                int Total = 0;
                while (cursor.moveToNext()){
                    buffer.append("Date: " + cursor.getString(0)+ " Price : " +cursor.getString(1) + "\n\n" );
                    Total += cursor.getInt(1);
                }
                showMessage("Report",buffer.toString() + "Total : " +Total);
            }

        }


    }

    public void showMessage(String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_example, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.REGISTER:
                intent = new Intent(this,RegisterActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDMATERIAL:
                intent = new Intent(this,AddEditMaterialActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAYOWNER:
                intent = new Intent(this,AddOutlayOwnerActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAY:
                intent = new Intent(this,AddOutlayActivity.class);
                startActivity (intent);
                return true;
            case R.id.MONTYEAR:
                intent = new Intent(this,MonthYearReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.OWNERREPORT:
                intent = new Intent(this,OutlayOwnerPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.MATERIALREPORT:
                intent = new Intent(this,MaterialPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.SERVICEREPORT:
                intent = new Intent(this,ServiceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.DASHBOARD:
                intent = new Intent(this,WelcomeActivity.class);
                startActivity (intent);
                return true;
            case R.id.SIGNOUT:
                intent = new Intent(this,MainActivity.class);
                startActivity (intent);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

}