package com.example.masrofk;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;

public class EditMaterialActivity extends AppCompatActivity {
    EditText et_name_material, et_description_material;
    Button bt_edit_material;
    RadioButton rd_yes, rd_no;
    public static final int DEFAULT_VALUE = -1;
    public static final String MO_DATA = "Mo data";
    SQLiteDatabase db;
    int id_help ;
    String name_help;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_material);
        et_name_material = findViewById(R.id.et_name_material1);
        et_description_material = findViewById(R.id.et_description_material1);
        bt_edit_material = findViewById(R.id.bt_edit_material1);
        rd_no = findViewById(R.id.rd_no1);
        rd_yes = findViewById(R.id.rd_yes1);
        Bundle a = getIntent().getExtras();
        String materialName = a.getString("name",MO_DATA);
        String materialIsService = a.getString("isService",MO_DATA);
        String materialDescription = a.getString("description",MO_DATA);
        int matrialID= a.getInt("id",DEFAULT_VALUE);
        db= openOrCreateDatabase("MasrofkDB", Context.MODE_PRIVATE,null);
        id_help = matrialID;
        name_help = materialName;
        et_name_material.setText(materialName);
        et_description_material.setText(materialDescription);
        if (materialIsService.equals("Yes")) {
            rd_yes.setChecked(true);
        } else  {
            rd_no.setChecked(true);
        }

    }

    public void onClick(View v){
        String isService = "";

        if (v==rd_yes) {
            isService = "yes";
        }
        if (v==rd_no) {
            isService="no";
        }
        if(v== bt_edit_material) {
            if (et_name_material.getText().toString().trim().length() == 0 ||
                    et_description_material.getText().toString().trim().length() == 0) {
                showMessage("Error", "Please enter all values");
                return;
            }
            Cursor c = db.rawQuery("SELECT * FROM material WHERE id='" + id_help + "'", null);
            if (c.moveToFirst()) {
                db.execSQL("UPDATE material SET name='" + et_name_material.getText() + "',isService='" + isService + "',description='" + et_description_material.getText() + "'  WHERE id='" + id_help + "'");
                Intent intent = new Intent(this,DisplayMaterialActivity.class);
                startActivity (intent);
            }
        }

    }

    public void showMessage(String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
//        builder.setIcon(R.drawable.ic_class_foreground);
        builder.show();
    }

    public void clearText(){
        et_name_material.setText("");
        et_description_material.setText("");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_example, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.REGISTER:
                intent = new Intent(this,RegisterActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDMATERIAL:
                intent = new Intent(this,AddEditMaterialActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAYOWNER:
                intent = new Intent(this,AddOutlayOwnerActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAY:
                intent = new Intent(this,AddOutlayActivity.class);
                startActivity (intent);
                return true;
            case R.id.MONTYEAR:
                intent = new Intent(this,MonthYearReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.OWNERREPORT:
                intent = new Intent(this,OutlayOwnerPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.MATERIALREPORT:
                intent = new Intent(this,MaterialPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.SERVICEREPORT:
                intent = new Intent(this,ServiceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.DASHBOARD:
                intent = new Intent(this,WelcomeActivity.class);
                startActivity (intent);
                return true;
            case R.id.SIGNOUT:
                intent = new Intent(this,MainActivity.class);
                startActivity (intent);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }
}