package com.example.masrofk;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;

public class DisplayMaterialActivity extends AppCompatActivity {
    ListView lv_material_data;
    String []name;
    String []description;
    String []isService;
    int []id;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_material);
        db= openOrCreateDatabase("MasrofkDB", Context.MODE_PRIVATE,null);
        lv_material_data = findViewById(R.id.lv_material_data);
        displayMaterialData();
    }


    public  void displayMaterialData () {
        Cursor cursor =db.rawQuery("SELECT * FROM material ",null);
        if(cursor.getCount() > 0) {
            id = new int[cursor.getCount()];
            name = new String[cursor.getCount()];
            description = new String[cursor.getCount()];
            isService = new String[cursor.getCount()];
            int i =0 ;
            while (cursor.moveToNext()){
                id[i] = cursor.getInt(0);
                name[i]=cursor.getString(1);
                isService[i]=cursor.getString(2);
                description[i]=cursor.getString(3);
                i++;
            }

            Custom adapter = new Custom();
            lv_material_data.setAdapter(adapter);
        }
    }

    private class Custom extends BaseAdapter {
        @Override
        public int getCount() {
            return name.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

            TextView textView;
            ImageView edit,delete;
            view = LayoutInflater.from(DisplayMaterialActivity.this).inflate(R.layout.single_data_material,viewGroup,false);
            textView = view.findViewById(R.id.txt_name);
            edit = view.findViewById(R.id.edit_data_material);
            delete = view.findViewById(R.id.delete_data_material);
            textView.setText(name[i]);
                edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("id",id[i]);
                    bundle.putString("name",name[i]);
                    bundle.putString("isService",isService[i]);
                    bundle.putString("description",description[i]);
                    Intent intent = new Intent(view.getContext(),EditMaterialActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
            });

            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Cursor c= db.rawQuery("SELECT * FROM material WHERE id='" + id[i] + "'",null);
                    if(c.moveToFirst())
                    {
                        db.execSQL("DELETE FROM material WHERE id='" + id[i] + "'");
                        showMessage("Success","Record Deleted");
                        displayMaterialData ();
                    }
                }
            });
        return view ;
        }


    }

    public void showMessage(String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
//        builder.setIcon(R.drawable.ic_class_foreground);
        builder.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_example, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.REGISTER:
                intent = new Intent(this,RegisterActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDMATERIAL:
                intent = new Intent(this,AddEditMaterialActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAYOWNER:
                intent = new Intent(this,AddOutlayOwnerActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAY:
                intent = new Intent(this,AddOutlayActivity.class);
                startActivity (intent);
                return true;
            case R.id.MONTYEAR:
                intent = new Intent(this,MonthYearReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.OWNERREPORT:
                intent = new Intent(this,OutlayOwnerPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.MATERIALREPORT:
                intent = new Intent(this,MaterialPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.SERVICEREPORT:
                intent = new Intent(this,ServiceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.DASHBOARD:
                intent = new Intent(this,WelcomeActivity.class);
                startActivity (intent);
                return true;
            case R.id.SIGNOUT:
                intent = new Intent(this,MainActivity.class);
                startActivity (intent);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }
}