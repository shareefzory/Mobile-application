package com.example.masrofk;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText et_Username, et_Password;
    Button bt_go_add_material,bt_go_add_outlay_owner,bt_go_monthyear,bt_go_add_outlay ;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et_Username = findViewById(R.id.et_Username);
        et_Password = findViewById(R.id.et_Password);
        bt_go_add_outlay = findViewById(R.id.bt_add_Outlay);
        bt_go_monthyear = findViewById(R.id.bt_go_monthyear);
        bt_go_add_material = findViewById(R.id.bt_go_add_material);
        bt_go_add_outlay_owner = findViewById(R.id.bt_go_add_outlayowner);
        db= openOrCreateDatabase("MasrofkDB", Context.MODE_PRIVATE,null);
    }


    public void onClick(View v){

        if(v== bt_go_add_material) {
            Intent intent = new Intent(this,AddEditMaterialActivity.class);
            startActivity (intent);
        }
        if(v== bt_go_add_outlay_owner) {
            Intent intent = new Intent(this,AddOutlayOwnerActivity.class);
            startActivity (intent);
        }
        if(v== bt_go_add_outlay) {
            Intent intent = new Intent(this,AddOutlayActivity.class);
            startActivity (intent);
        }
        if(v== bt_go_monthyear) {
            Intent intent = new Intent(this,ServiceReportActivity.class);
            startActivity (intent);
        }


    }
    public void startWelcomeActivity(View v){
        if(et_Username.getText().toString().trim().length()==0 ||
                et_Password.getText().toString().trim().length()==0)
        {
            showMessage("Error","Please Enter All fields");
            return;
        }
        Cursor c=db.rawQuery("SELECT * FROM user WHERE username='" + et_Username.getText() + "'" + "AND password='" + et_Password.getText() + "'",null);
        if(c.moveToFirst())
        {
            Intent intent = new Intent(this,WelcomeActivity.class);
            startActivity (intent);
        } else
        {
            showMessage("Error","Username or Password not Correct");
            clearText();
        }
    }

    public void startRegisterActivity(View v){
        Intent intent = new Intent(this,RegisterActivity.class);
        startActivity (intent);
    }

    public void showMessage(String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText(){
        et_Username.setText("");
        et_Password.setText("");
    }




}