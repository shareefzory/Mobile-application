package com.example.masrofk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class WelcomeActivity extends AppCompatActivity {
    Button bt_go_add_material,bt_go_add_outlay_owner ,bt_go_monthyear,bt_go_add_outlay,bt_owner_report,bt_material_report,bt_service_report;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        bt_go_add_material = findViewById(R.id.bt_go_add_material);
        bt_go_add_outlay_owner = findViewById(R.id.bt_go_add_outlayowner);
        bt_go_monthyear = findViewById(R.id.bt_go_monthyear);
        bt_go_add_outlay = findViewById(R.id.bt_go_add_outlay);
        bt_owner_report = findViewById(R.id.bt_owner_report);
        bt_material_report =findViewById(R.id.bt_material_report);
        bt_service_report = findViewById(R.id.bt_service_report);
    }
    public void onClick(View v){

        if(v== bt_go_add_material) {
            Intent intent = new Intent(this,AddEditMaterialActivity.class);
            startActivity (intent);
        }
        if(v== bt_go_add_outlay_owner) {
            Intent intent = new Intent(this,AddOutlayOwnerActivity.class);
            startActivity (intent);
        }
        if(v== bt_go_add_outlay) {
            Intent intent = new Intent(this,AddOutlayActivity.class);
            startActivity (intent);
        }
        if(v== bt_go_monthyear) {
            Intent intent = new Intent(this,MonthYearReportActivity.class);
            startActivity (intent);
        }
        if(v== bt_owner_report) {
            Intent intent = new Intent(this,OutlayOwnerPriceReportActivity.class);
            startActivity (intent);
        }
        if(v== bt_material_report) {
            Intent intent = new Intent(this,MaterialPriceReportActivity.class);
            startActivity (intent);
        }
        if(v== bt_service_report) {
            Intent intent = new Intent(this,ServiceReportActivity.class);
            startActivity (intent);
        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_example, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.REGISTER:
                intent = new Intent(this,RegisterActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDMATERIAL:
                intent = new Intent(this,AddEditMaterialActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAYOWNER:
                intent = new Intent(this,AddOutlayOwnerActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAY:
                intent = new Intent(this,AddOutlayActivity.class);
                startActivity (intent);
                return true;
            case R.id.MONTYEAR:
                intent = new Intent(this,MonthYearReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.OWNERREPORT:
                intent = new Intent(this,OutlayOwnerPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.MATERIALREPORT:
                intent = new Intent(this,MaterialPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.SERVICEREPORT:
                intent = new Intent(this,ServiceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.DASHBOARD:
                intent = new Intent(this,WelcomeActivity.class);
                startActivity (intent);
                return true;
            case R.id.SIGNOUT:
                intent = new Intent(this,MainActivity.class);
                startActivity (intent);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }
}