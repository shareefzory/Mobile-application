package com.example.masrofk;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddOutlayOwnerActivity extends AppCompatActivity {
    EditText et_name_OutlayOwner, et_description_OutlayOwner;
    Button bt_add_OutlayOwner, bt_view_OutlayOwner, edit;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_outlay_owner);
        et_name_OutlayOwner = findViewById(R.id.et_name_OutlayOwner);
        et_description_OutlayOwner = findViewById(R.id.et_description_OutlayOwner);
        bt_add_OutlayOwner = findViewById(R.id.bt_add_OutlayOwner);
        bt_view_OutlayOwner = findViewById(R.id.bt_view_OutlayOwner);
        db= openOrCreateDatabase("MasrofkDB", Context.MODE_PRIVATE,null);
        db.execSQL("CREATE TABLE IF NOT EXISTS OutlayOwner (id INTEGER PRIMARY KEY AUTOINCREMENT, name VARCHAR,description VARCHAR);");
    }

    public void onClick(View v){
        if(v== bt_add_OutlayOwner){
            if(et_name_OutlayOwner.getText().toString().trim().length()==0 ||
                    et_description_OutlayOwner.getText().toString().trim().length()==0)
            {
                showMessage("Error","Please enter all values");
                return;
            }
            ContentValues contentValues=new ContentValues();
            contentValues.put("name",et_name_OutlayOwner.getText().toString());
            db.execSQL("INSERT INTO OutlayOwner (name,description) VALUES('" + et_name_OutlayOwner.getText() + "','" + et_description_OutlayOwner.getText() + "');");
            showMessage("Success","Record added");
            clearText();
        }
        if(v == bt_view_OutlayOwner) {
            Intent intent = new Intent(this, DisplayOutlayOwnerActivity.class);
            startActivity (intent);
        }
    }

    public void showMessage(String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void clearText(){
        et_name_OutlayOwner.setText("");
        et_description_OutlayOwner.setText("");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_example, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.REGISTER:
                intent = new Intent(this,RegisterActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDMATERIAL:
                intent = new Intent(this,AddEditMaterialActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAYOWNER:
                intent = new Intent(this,AddOutlayOwnerActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAY:
                intent = new Intent(this,AddOutlayActivity.class);
                startActivity (intent);
                return true;
            case R.id.MONTYEAR:
                intent = new Intent(this,MonthYearReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.OWNERREPORT:
                intent = new Intent(this,OutlayOwnerPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.MATERIALREPORT:
                intent = new Intent(this,MaterialPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.SERVICEREPORT:
                intent = new Intent(this,ServiceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.DASHBOARD:
                intent = new Intent(this,WelcomeActivity.class);
                startActivity (intent);
                return true;
            case R.id.SIGNOUT:
                intent = new Intent(this,MainActivity.class);
                startActivity (intent);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

}