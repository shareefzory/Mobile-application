package com.example.masrofk;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;

public class AddOutlayActivity extends AppCompatActivity {
    // Spinner element
    Spinner spinner_OutlayOwner,spinner_material;
    EditText et_price_Outlay,et_description_Outlay;
    Button bt_view_Outlay,bt_add_Outlay;
    String []name_material;
    String []name_OutlayOwner;
    int []id_material;
    int []id_OutlayOwner;
    int id_material_help, id_OutlayOwner_help,price_help;
    CalendarView mCalendarView;
    String date_help;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_outlay);
        spinner_material = (Spinner) findViewById(R.id.spinner_material);
        spinner_OutlayOwner = (Spinner) findViewById(R.id.spinner_OutlayOwner);
        et_price_Outlay = findViewById(R.id.et_price_Outlay);
        et_description_Outlay = findViewById(R.id.et_description_Outlay);
        bt_add_Outlay = findViewById(R.id.bt_add_Outlay);
        bt_view_Outlay =findViewById(R.id.bt_view_Outlay);
        db= openOrCreateDatabase("MasrofkDB", Context.MODE_PRIVATE,null);
        db.execSQL("CREATE TABLE IF NOT EXISTS Outlay(id INTEGER PRIMARY KEY AUTOINCREMENT,Material_id INTEGER ,OutlayOwner_id INTEGER,price INTEGER,date TEXT, description VARCHAR,FOREIGN KEY (Material_id) REFERENCES material (id),FOREIGN KEY (OutlayOwner_id) REFERENCES OutlayOwner (id) );");
//        db.execSQL("DROP TABLE IF EXISTS Outlay");
        loadSpinnerDataMaterial();
        loadSpinnerDataOutlayOwner();
//        setContentView(R.layout.calendar_layout);
        mCalendarView = (CalendarView) findViewById(R.id.calendarView);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView CalendarView, int year, int month, int dayOfMonth) {
                String date = year + "/" + month + "/"+ dayOfMonth ;
                date_help = date;
            }
        });
        spinner_material.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long arg3) {
                 spinner_material.setSelection(position);
                 id_material_help = id_material[position];
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });

        spinner_OutlayOwner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long arg3) {
//                Arrays.asList(id_OutlayOwner).get(position);
                spinner_OutlayOwner.setSelection(position);
                id_OutlayOwner_help = id_OutlayOwner[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });

    }

    public void onClick(View v){
        if(v== bt_add_Outlay){
            if(et_price_Outlay.getText().toString().trim().length()==0 ||
                    et_description_Outlay.getText().toString().trim().length()==0)
            {
                showMessage("Error","Please enter all values");
                return;
            }
            price_help = Integer.parseInt(et_price_Outlay.getText().toString());
            db.execSQL("INSERT INTO Outlay(Material_id,OutlayOwner_id,price,date,description) VALUES('" + id_material_help + "','" + id_OutlayOwner_help + "','" + price_help + "','" + date_help + "','" +  et_description_Outlay.getText() +  "');");
            showMessage("Success","Record added");
            clearText();
        }
        if(v == bt_view_Outlay) {
            Intent intent = new Intent(this, DisplayOutlayActivity.class);
            startActivity (intent);
        }
    }

    public void showMessage(String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void clearText(){
        et_price_Outlay.setText("");
        et_description_Outlay.setText("");
    }


    private void loadSpinnerDataMaterial() {
        Cursor cursor =db.rawQuery("SELECT * FROM material ",null);
        if(cursor.getCount() > 0) {
            id_material = new int[cursor.getCount()];
            name_material = new String[cursor.getCount()];
            int i =0 ;
            while (cursor.moveToNext()){
                id_material[i] = cursor.getInt(0);
                name_material[i]=cursor.getString(1);
                i++;
            }
            // Spinner Drop down elements
            List<String> lables = Arrays.asList(name_material);

            // Creating adapter for spinner
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, lables);

            // Drop down layout style - list view with radio button
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            // attaching data adapter to spinner
            spinner_material.setAdapter(dataAdapter);
        }
    }
    private void loadSpinnerDataOutlayOwner() {
        Cursor cursor =db.rawQuery("SELECT * FROM OutlayOwner ",null);
        if(cursor.getCount() > 0) {
            id_OutlayOwner = new int[cursor.getCount()];
            name_OutlayOwner = new String[cursor.getCount()];
            int i =0 ;
            while (cursor.moveToNext()){
                id_OutlayOwner[i] = cursor.getInt(0);
                name_OutlayOwner[i]=cursor.getString(1);
                i++;
            }
            // Spinner Drop down elements
            List<String> lables = Arrays.asList(name_OutlayOwner);

            // Creating adapter for spinner
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, lables);

            // Drop down layout style - list view with radio button
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            // attaching data adapter to spinner
            spinner_OutlayOwner.setAdapter(dataAdapter);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_example, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.REGISTER:
                intent = new Intent(this,RegisterActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDMATERIAL:
                intent = new Intent(this,AddEditMaterialActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAYOWNER:
                intent = new Intent(this,AddOutlayOwnerActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAY:
                intent = new Intent(this,AddOutlayActivity.class);
                startActivity (intent);
                return true;
            case R.id.MONTYEAR:
                intent = new Intent(this,MonthYearReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.OWNERREPORT:
                intent = new Intent(this,OutlayOwnerPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.MATERIALREPORT:
                intent = new Intent(this,MaterialPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.SERVICEREPORT:
                intent = new Intent(this,ServiceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.DASHBOARD:
                intent = new Intent(this,WelcomeActivity.class);
                startActivity (intent);
                return true;
            case R.id.SIGNOUT:
                intent = new Intent(this,MainActivity.class);
                startActivity (intent);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }



}