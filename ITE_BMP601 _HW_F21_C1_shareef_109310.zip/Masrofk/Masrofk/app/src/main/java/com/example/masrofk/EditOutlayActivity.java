package com.example.masrofk;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Arrays;
import java.util.List;

public class EditOutlayActivity extends AppCompatActivity {
    Spinner spinner_OutlayOwner,spinner_material;
    TextView tv_date;
    EditText et_price_Outlay,et_description_Outlay;
    Button bt_edit_Outlay;
    String []name_material;
    String []name_OutlayOwner;
    String date_help;
    CalendarView mCalendarView;
    int id_help , price_help ;
    int []id_material;
    int []id_OutlayOwner;
    int id_material_help, id_OutlayOwner_help;
    public static final int DEFAULT_VALUE = -1;
    public static final String MO_DATA = "Mo data";
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_outlay);
        spinner_material = (Spinner) findViewById(R.id.spinner_material);
        spinner_OutlayOwner = (Spinner) findViewById(R.id.spinner_OutlayOwner);
        et_price_Outlay = findViewById(R.id.et_price_Outlay);
        et_description_Outlay = findViewById(R.id.et_description_Outlay);
        bt_edit_Outlay = findViewById(R.id.bt_edit_Outlay);
        tv_date = findViewById(R.id.tv_date);
        Bundle a = getIntent().getExtras();
        int outlay_id = a.getInt("id",DEFAULT_VALUE);
        int material_id = a.getInt("material_id",DEFAULT_VALUE);
        int OutlayOwner_id = a.getInt("OutlayOwner_id",DEFAULT_VALUE);
        int price = a.getInt("price",DEFAULT_VALUE);
        String date = a.getString("date",MO_DATA);
        String description = a.getString("description",MO_DATA);
        db= openOrCreateDatabase("MasrofkDB", Context.MODE_PRIVATE,null);
        loadSpinnerDataMaterial();
        loadSpinnerDataOutlayOwner();
        id_help = outlay_id;
        et_price_Outlay.setText(price);
        tv_date.setText(date);
        mCalendarView = (CalendarView) findViewById(R.id.calendarView);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView CalendarView, int year, int month, int dayOfMonth) {
                String date = year + "/" + month + "/"+ dayOfMonth ;
                date_help = date;
            }
        });
        et_description_Outlay.setText(description);
        spinner_material.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long arg3) {
                spinner_material.setSelection(position);
                id_material_help = id_material[position];
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });

        spinner_OutlayOwner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long arg3) {
//                Arrays.asList(id_OutlayOwner).get(position);
                spinner_OutlayOwner.setSelection(position);
                id_OutlayOwner_help = id_OutlayOwner[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
    }


    private void loadSpinnerDataMaterial() {
        Cursor cursor =db.rawQuery("SELECT * FROM material ",null);
        if(cursor.getCount() > 0) {
            id_material = new int[cursor.getCount()];
            name_material = new String[cursor.getCount()];
            int i =0 ;
            while (cursor.moveToNext()){
                id_material[i] = cursor.getInt(0);
                name_material[i]=cursor.getString(1);
                i++;
            }
            // Spinner Drop down elements
            List<String> lables = Arrays.asList(name_material);

            // Creating adapter for spinner
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, lables);

            // Drop down layout style - list view with radio button
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            // attaching data adapter to spinner
            spinner_material.setAdapter(dataAdapter);
        }
    }
    private void loadSpinnerDataOutlayOwner() {
        Cursor cursor =db.rawQuery("SELECT * FROM OutlayOwner ",null);
        if(cursor.getCount() > 0) {
            id_OutlayOwner = new int[cursor.getCount()];
            name_OutlayOwner = new String[cursor.getCount()];
            int i =0 ;
            while (cursor.moveToNext()){
                id_OutlayOwner[i] = cursor.getInt(0);
                name_OutlayOwner[i]=cursor.getString(1);
                i++;
            }
            // Spinner Drop down elements
            List<String> lables = Arrays.asList(name_OutlayOwner);

            // Creating adapter for spinner
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, lables);

            // Drop down layout style - list view with radio button
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            // attaching data adapter to spinner
            spinner_OutlayOwner.setAdapter(dataAdapter);
        }

    }

    public void onClick(View v){
        if(v== bt_edit_Outlay) {
            if (et_price_Outlay.getText().toString().trim().length() == 0 ||
                    et_description_Outlay.getText().toString().trim().length() == 0) {
                showMessage("Error", "Please enter all values");
                return;
            }
            price_help = Integer.parseInt(et_price_Outlay.getText().toString());
            Cursor c = db.rawQuery("SELECT * FROM Outlay WHERE id='" + id_help + "'", null);
            if (c.moveToFirst()) {
                db.execSQL("UPDATE Outlay SET Material_id='" + id_material_help + "',OutlayOwner_id='" + id_OutlayOwner_help +  "' ,price='" + price_help + "' ,date='" + date_help + "' ,description='" + et_description_Outlay.getText() + "'  WHERE id='" + id_help + "'");
                Intent intent = new Intent(this, DisplayOutlayActivity.class);
                startActivity (intent);
            }
        }

    }
    public void showMessage(String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_example, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.REGISTER:
                intent = new Intent(this,RegisterActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDMATERIAL:
                intent = new Intent(this,AddEditMaterialActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAYOWNER:
                intent = new Intent(this,AddOutlayOwnerActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAY:
                intent = new Intent(this,AddOutlayActivity.class);
                startActivity (intent);
                return true;
            case R.id.MONTYEAR:
                intent = new Intent(this,MonthYearReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.OWNERREPORT:
                intent = new Intent(this,OutlayOwnerPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.MATERIALREPORT:
                intent = new Intent(this,MaterialPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.SERVICEREPORT:
                intent = new Intent(this,ServiceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.DASHBOARD:
                intent = new Intent(this,WelcomeActivity.class);
                startActivity (intent);
                return true;
            case R.id.SIGNOUT:
                intent = new Intent(this,MainActivity.class);
                startActivity (intent);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }
}