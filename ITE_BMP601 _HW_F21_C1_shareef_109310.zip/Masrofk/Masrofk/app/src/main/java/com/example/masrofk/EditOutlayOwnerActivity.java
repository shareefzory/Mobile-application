package com.example.masrofk;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class EditOutlayOwnerActivity extends AppCompatActivity {
    EditText et_name_OutlayOwner, et_description_OutlayOwner;
    Button bt_edit_OutlayOwner;
    public static final int DEFAULT_VALUE = -1;
    public static final String MO_DATA = "Mo data";
    SQLiteDatabase db;
    int id_help ;
    String name_help;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_outlay_owner);
        et_name_OutlayOwner = findViewById(R.id.et_name_OutlayOwner1);
        et_description_OutlayOwner = findViewById(R.id.et_description_OutlayOwner1);
        bt_edit_OutlayOwner = findViewById(R.id.bt_edit_OutlayOwner1);
        Bundle a = getIntent().getExtras();
        String OutlayOwnerName = a.getString("name",MO_DATA);
        String OutlayOwnerDescription = a.getString("description",MO_DATA);
        int OutlayOwnerID= a.getInt("id",DEFAULT_VALUE);
        db= openOrCreateDatabase("MasrofkDB", Context.MODE_PRIVATE,null);
        id_help = OutlayOwnerID;
        name_help = OutlayOwnerName;
        et_name_OutlayOwner.setText(OutlayOwnerName);
        et_description_OutlayOwner.setText(OutlayOwnerDescription);
    }

    public void onClick(View v){
        if(v== bt_edit_OutlayOwner) {
            if (et_name_OutlayOwner.getText().toString().trim().length() == 0 ||
                    et_description_OutlayOwner.getText().toString().trim().length() == 0) {
                showMessage("Error", "Please enter all values");
                return;
            }
            Cursor c = db.rawQuery("SELECT * FROM OutlayOwner WHERE id='" + id_help + "'", null);
            if (c.moveToFirst()) {
                db.execSQL("UPDATE OutlayOwner SET name='" + et_name_OutlayOwner.getText() + "',description='" + et_description_OutlayOwner.getText() + "'  WHERE id='" + id_help + "'");
                Intent intent = new Intent(this, DisplayOutlayOwnerActivity.class);
                startActivity (intent);
            }
        }

    }
    public void showMessage(String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText(){
        et_name_OutlayOwner.setText("");
        et_description_OutlayOwner.setText("");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_example, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.REGISTER:
                intent = new Intent(this,RegisterActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDMATERIAL:
                intent = new Intent(this,AddEditMaterialActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAYOWNER:
                intent = new Intent(this,AddOutlayOwnerActivity.class);
                startActivity (intent);
                return true;
            case R.id.ADDOUTLAY:
                intent = new Intent(this,AddOutlayActivity.class);
                startActivity (intent);
                return true;
            case R.id.MONTYEAR:
                intent = new Intent(this,MonthYearReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.OWNERREPORT:
                intent = new Intent(this,OutlayOwnerPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.MATERIALREPORT:
                intent = new Intent(this,MaterialPriceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.SERVICEREPORT:
                intent = new Intent(this,ServiceReportActivity.class);
                startActivity (intent);
                return true;
            case R.id.DASHBOARD:
                intent = new Intent(this,WelcomeActivity.class);
                startActivity (intent);
                return true;
            case R.id.SIGNOUT:
                intent = new Intent(this,MainActivity.class);
                startActivity (intent);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }
}